---
name: Antigravity
colors:
  surface: '#0d1515'
  surface-dim: '#0d1515'
  surface-bright: '#333b3b'
  surface-container-lowest: '#080f10'
  surface-container-low: '#151d1e'
  surface-container: '#192122'
  surface-container-high: '#232b2c'
  surface-container-highest: '#2e3637'
  on-surface: '#dce4e4'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#dce4e4'
  inverse-on-surface: '#2a3232'
  outline: '#849495'
  outline-variant: '#3a494b'
  surface-tint: '#00dbe7'
  primary: '#e1fdff'
  on-primary: '#00363a'
  primary-container: '#00f2ff'
  on-primary-container: '#006a71'
  inverse-primary: '#00696f'
  secondary: '#d0bcff'
  on-secondary: '#3c0091'
  secondary-container: '#571bc1'
  on-secondary-container: '#c4abff'
  tertiary: '#fff6e4'
  on-tertiary: '#3b2f00'
  tertiary-container: '#fed83a'
  on-tertiary-container: '#725e00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#74f5ff'
  primary-fixed-dim: '#00dbe7'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#23005c'
  on-secondary-fixed-variant: '#5516be'
  tertiary-fixed: '#ffe173'
  tertiary-fixed-dim: '#e8c423'
  on-tertiary-fixed: '#221b00'
  on-tertiary-fixed-variant: '#554500'
  background: '#0d1515'
  on-background: '#dce4e4'
  surface-variant: '#2e3637'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: 0.05em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.15em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  container-max: 1200px
  gutter: 1.5rem
  margin-mobile: 1rem
  stack-sm: 0.5rem
  stack-md: 1.5rem
  stack-lg: 3rem
---

## Brand & Style
The design system is a futuristic, immersive interface that evokes the feeling of floating in deep space. It targets a tech-forward academic audience, specifically for the VVM 2026-27 Mock Test, blending high-stakes competitive energy with a clean, experimental aesthetic.

The style is a hybrid of **Glassmorphism** and **Minimalist Futurism**. It utilizes deep obsidian voids as a canvas for floating, translucent modules. Elements should feel weightless, separated from the background by subtle glow effects rather than heavy shadows. The interface must remain highly functional for educational content while maintaining a "heads-up display" (HUD) feel.

**CREATED BY SIRAJ HOSSAIN**

## Colors
This design system uses a high-contrast dark theme.
- **Deep Space Obsidian (#0a0a0c):** Used for all primary backgrounds to create a sense of infinite depth.
- **Electric Cyan (#00f2ff):** The primary action color, used for interactive elements, progress indicators, and "active" states.
- **Neon Violet (#8b5cf6):** The secondary accent, used for branding, highlighting specific academic categories, and decorative gradients.
- **Silver/White:** Pure white for primary headers and Bengali body text; Zinc-400 for secondary metadata to ensure hierarchy.
- **Gradients:** Use linear gradients from Cyan to Violet (45 degrees) for primary buttons and high-priority progress bars.

## Typography
The typography is designed for technical precision and readability. **Inter** provides the backbone for both English and Bengali script, ensuring clarity in an academic context. **Space Grotesk** is used sparingly for labels and data points to reinforce the futuristic theme.

**Bengali Text Considerations:** 
Maintain a slightly higher line-height (1.6x) for Bengali body text to accommodate complex ligatures. Ensure that weight increases are distinct to help students scan questions quickly. Use high tracking (letter-spacing) only for English uppercase labels; keep Bengali tracking at default for legibility.

## Layout & Spacing
The design system employs a **fluid grid** with generous internal padding to create "breathable" modules that appear to float. 

- **Desktop:** 12-column grid with 24px gutters. Content should be centered within a 1200px container.
- **Tablet:** 8-column grid with 20px gutters.
- **Mobile:** 4-column grid with 16px margins. 

Use "Stack" spacing for vertical rhythm: `stack-md` between question blocks and `stack-sm` between an academic question and its multiple-choice options.

## Elevation & Depth
Depth is achieved through **Glassmorphism** and luminosity rather than traditional shadows.

1.  **Background Surface:** Pure `#0a0a0c`.
2.  **Floating Cards:** Background of `rgba(255, 255, 255, 0.03)` with a `backdrop-filter: blur(12px)`.
3.  **Borders:** 1px solid `rgba(0, 242, 255, 0.2)`. On hover or focus, the border opacity increases to `0.8` with a subtle outer glow (`box-shadow: 0 0 15px rgba(0, 242, 255, 0.3)`).
4.  **Z-Index Hierarchy:** Use higher blur values and lighter border tints for elements that are "closer" to the user (e.g., modals or active tooltips).

## Shapes
The shape language is sharp and precise. A "Soft" (`0.25rem`) corner radius is the standard for cards and inputs to maintain a technical, architectural feel. 

- **Buttons:** Use `rounded-lg` (0.5rem) for a more approachable feel while keeping the technical edge.
- **Selection Circles:** Radio buttons for the mock test should be perfect circles to contrast with the rectangular grid of the UI.

## Components
- **Question Cards:** Translucent glass panels with a thin Cyan top-border. Question numbers should be in Space Grotesk for a HUD effect.
- **Buttons (Primary):** Gradient fill (Cyan to Violet), white text, 0.5rem roundedness. Add a `hover: scale(1.02)` transition to simulate anti-gravity.
- **Buttons (Secondary):** Ghost style with a 1px Cyan border and transparent background.
- **Input Fields:** Darker than the background (`#000000`), subtle Cyan bottom-border only.
- **Progress Bar (Mock Test):** A thin 4px line at the top of the screen using a Cyan-to-Violet gradient, glowing against the obsidian background.
- **Option Selection:** When an answer is selected, the entire option block should fill with a `rgba(0, 242, 255, 0.1)` tint and the border should glow.
- **Footer:** Minimalist. "CREATED BY SIRAJ HOSSAIN" should be centered in `label-sm` typography, Zinc-500 color.